package com.example.myapplicationcardrecycle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private MahasiswaAdapter adapter;
    private ArrayList<Mahasiswa> mahasiswaArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addData();

        recyclerView = findViewById(R.id.recycler_view);

        adapter = new MahasiswaAdapter(mahasiswaArrayList);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);

        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(adapter);
    }

    void addData(){
        mahasiswaArrayList = new ArrayList<>();
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana01", "121437809801", "09875812401"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana02", "121437809802", "09875812402"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana03", "121437809803", "09875812403"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana04", "121437809804", "09875812404"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana05", "121437809805", "09875812405"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana06", "121437809806", "09875812406"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana07", "121437809807", "09875812407"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana08", "121437809808", "09875812408"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana09", "121437809809", "09875812409"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana10", "121437809810", "09875812410"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana11", "121437809801", "09875812411"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana12", "121437809801", "09875812412"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana13", "121437809803", "09875812413"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana14", "121437809804", "09875812414"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana15", "121437809805", "09875812415"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana16", "121437809806", "09875812416"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana17", "121437809807", "09875812417"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana18", "121437809808", "09875812418"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana19", "121437809809", "09875812419"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana20", "121437809810", "09875812420"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana21", "121437809821", "09875812421"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana22", "121437809821", "09875812422"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana23", "121437809823", "09875812423"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana24", "121437809824", "09875812424"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana25", "121437809825", "09875812425"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana26", "121437809826", "09875812426"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana27", "121437809827", "09875812427"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana28", "121437809828", "09875812428"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana29", "121437809829", "09875812429"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana30", "121437809830", "09875812430"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana31", "121437809831", "09875812431"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana32", "121437809832", "09875812432"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana33", "121437809833", "09875812433"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana34", "121437809834", "09875812434"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana35", "121437809835", "09875812435"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana36", "121437809836", "09875812436"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana37", "121437809837", "09875812437"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana38", "121437809838", "09875812438"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana39", "121437809839", "09875812439"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana40", "121437809840", "09875812440"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana41", "121437809841", "09875812441"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana42", "121437809841", "09875812442"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana43", "121437809843", "09875812443"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana44", "121437809844", "09875812444"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana45", "121437809845", "09875812445"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana46", "121437809846", "09875812446"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana47", "121437809847", "09875812447"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana48", "121437809848", "09875812448"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana49", "121437809849", "09875812449"));
        mahasiswaArrayList.add(new Mahasiswa("Aham Siswana50", "121437809850", "09875812450"));
    }

}
